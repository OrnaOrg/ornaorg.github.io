<ornaRiot>
    <h2 class="c_#ee0645 arial textincenter">{message1} </h2>
    <h3 class="arial textincenter">{message2} </h3>
    <ul class="center block bgc_skyblue_thisli_over bgc_white_thisli_out fs_20px w_150px p_4px_li mt_10px_li ">
        <li each={ lib }><a href={web} class="td_none c_black">{ name }</a>
        </li>
    </ul>
    <script>
        this.message1 = 'Hello, try RiotJS and OrnaJS together!'
        this.message2 = 'All library, that we use!'
        this.lib = [{
            name: 'jquery.js',
            web: 'http://jquery.com'
        }, {
            name: 'orna.js',
            web: 'http://ornaorg.github.io'
        }, {
            name: 'riot.js',
            web: 'http://riotjs.com'
        }];
        this.on('mount', function() {
            createatom();
        });
    </script>
</ornaRiot> 
    //http://riotjs.com 
    //http://ornaorg.github.io